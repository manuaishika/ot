import pandas as pd
import numpy as np

class SignalMatchedStrategy:
    """
    Signal-Matched Trading Strategy
    
    Based on empirical analysis showing strong correlations:
    - stock1 ← signal9 (r=0.334)
    - stock2 ← signal8 (r=0.363)
    - stock3 ← signal6 (r=0.353)
    """
    
    def __init__(self, position_scale=12.0, signal_threshold=0.0005):
        self.signal_map = {
            'stock1': 'signal9',
            'stock2': 'signal8',
            'stock3': 'signal6'
        }
        self.position_scale = position_scale
        self.signal_threshold = signal_threshold
        
    def generate_positions(self, df):
        """Generate trading positions from signals"""
        positions = pd.DataFrame(index=df.index)
        
        for stock, signal in self.signal_map.items():
            if signal not in df.columns:
                positions[stock] = 0
                continue
                
            raw_position = df[signal] * self.position_scale
            positions[stock] = np.where(
                abs(df[signal]) > self.signal_threshold,
                raw_position,
                0
            )
            
        return positions
    
    def calculate_returns(self, df, positions):
        """Calculate strategy returns with proper alignment"""
        returns = pd.DataFrame(index=df.index)
        
        for stock in ['stock1', 'stock2', 'stock3']:
            if stock not in df.columns:
                continue
                
            stock_returns = df[stock].pct_change()
            returns[f'{stock}_pnl'] = positions[stock].shift(1) * stock_returns
        
        pnl_cols = [col for col in returns.columns if '_pnl' in col]
        if pnl_cols:
            returns['portfolio_return'] = returns[pnl_cols].mean(axis=1)
        else:
            returns['portfolio_return'] = 0
        
        return returns
    
    def backtest(self, df):
        """Run complete backtest with metrics"""
        positions = self.generate_positions(df)
        returns = self.calculate_returns(df, positions)
        
        portfolio_returns = returns['portfolio_return'].dropna()
        
        if len(portfolio_returns) == 0:
            return positions, returns, self._empty_metrics()
        
        cumulative_returns = (1 + portfolio_returns).cumprod()
        
        metrics = {
            'total_return': portfolio_returns.sum(),
            'mean_return': portfolio_returns.mean(),
            'std_return': portfolio_returns.std(),
            'sharpe_ratio': self._calculate_sharpe(portfolio_returns),
            'max_drawdown': self._calculate_max_drawdown(cumulative_returns),
            'win_rate': (portfolio_returns > 0).sum() / len(portfolio_returns),
            'num_trades': (positions.diff().abs() > 0).sum().sum(),
            'final_pnl': cumulative_returns.iloc[-1] if len(cumulative_returns) > 0 else 1.0
        }
        
        return positions, returns, metrics
    
    def _calculate_sharpe(self, returns, periods_per_year=252):
        """Calculate annualized Sharpe ratio"""
        if len(returns) == 0 or returns.std() == 0:
            return 0.0
        return returns.mean() / returns.std() * np.sqrt(periods_per_year)
    
    def _calculate_max_drawdown(self, cumulative_returns):
        """Calculate maximum drawdown"""
        if len(cumulative_returns) == 0:
            return 0.0
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        return drawdown.min()
    
    def _empty_metrics(self):
        """Return empty metrics dictionary"""
        return {
            'total_return': 0.0,
            'mean_return': 0.0,
            'std_return': 0.0,
            'sharpe_ratio': 0.0,
            'max_drawdown': 0.0,
            'win_rate': 0.0,
            'num_trades': 0,
            'final_pnl': 1.0
        }
    
    def predict(self, df):
        """Generate predictions (portfolio returns)"""
        positions = self.generate_positions(df)
        returns = self.calculate_returns(df, positions)
        return returns['portfolio_return'].fillna(0)
