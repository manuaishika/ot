import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import TimeSeriesSplit
import sys
sys.path.append('..')
from strategy import SignalMatchedStrategy

print("="*70)
print("STRATEGY BACKTESTING")
print("="*70)

df = pd.read_csv('train.csv')
strategy = SignalMatchedStrategy()

tscv = TimeSeriesSplit(n_splits=5)
cv_results = []

print("\nTime-Series Cross-Validation:\n")

for fold, (train_idx, test_idx) in enumerate(tscv.split(df)):
    test_data = df.iloc[test_idx]
    _, _, metrics = strategy.backtest(test_data)
    
    print(f"Fold {fold+1}:")
    print(f"  Sharpe: {metrics['sharpe_ratio']:.3f}")
    print(f"  Return: {metrics['total_return']:.4f}")
    print(f"  Win Rate: {metrics['win_rate']:.3f}\n")
    
    cv_results.append(metrics)

print("="*70)
print("CV SUMMARY")
print("="*70)
sharpe_mean = np.mean([m['sharpe_ratio'] for m in cv_results])
print(f"Mean Sharpe: {sharpe_mean:.3f}")

positions, returns, full_metrics = strategy.backtest(df)

print("\n" + "="*70)
print("FULL BACKTEST")
print("="*70)
for key, value in full_metrics.items():
    if isinstance(value, float):
        print(f"{key}: {value:.6f}")
    else:
        print(f"{key}: {value}")

portfolio_returns = returns['portfolio_return'].dropna()
cumulative_pnl = (1 + portfolio_returns).cumprod()

fig = plt.figure(figsize=(16, 10))

ax1 = plt.subplot(2, 2, 1)
ax1.plot(cumulative_pnl.values, linewidth=2)
ax1.set_title('Cumulative Returns')
ax1.grid(True, alpha=0.3)

ax2 = plt.subplot(2, 2, 2)
rolling_sharpe = portfolio_returns.rolling(252).apply(
    lambda x: x.mean() / x.std() * np.sqrt(252) if len(x) > 1 and x.std() > 0 else 0
)
ax2.plot(rolling_sharpe.values, linewidth=2, color='orange')
ax2.set_title('Rolling Sharpe')
ax2.grid(True, alpha=0.3)

ax3 = plt.subplot(2, 2, 3)
ax3.hist(portfolio_returns, bins=50, edgecolor='black', alpha=0.7)
ax3.set_title('Return Distribution')
ax3.axvline(0, color='red', linestyle='--')

ax4 = plt.subplot(2, 2, 4)
running_max = cumulative_pnl.expanding().max()
drawdown = (cumulative_pnl - running_max) / running_max
ax4.plot(drawdown.values, linewidth=2, color='darkred')
ax4.fill_between(range(len(drawdown)), drawdown.values, 0, alpha=0.3, color='red')
ax4.set_title('Drawdown')
ax4.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('backtest_results.png', dpi=150, bbox_inches='tight')
print("\n✓ Saved backtest_results.png")
print("✓ BACKTEST COMPLETE")
