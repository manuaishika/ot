import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

print("="*70)
print("EXPLORATORY DATA ANALYSIS")
print("="*70)

df = pd.read_csv('train.csv')

print(f"\nDataset Shape: {df.shape}")
print(f"Columns: {df.columns.tolist()}")

signal_cols = [col for col in df.columns if 'signal' in col.lower()]
stock_cols = [col for col in df.columns if 'stock' in col.lower()]

for stock in stock_cols:
    df[f'{stock}_return'] = df[stock].pct_change()

print("\n" + "="*70)
print("SIGNAL-RETURN CORRELATIONS")
print("="*70)

correlation_results = []

for stock in stock_cols:
    return_col = f'{stock}_return'
    print(f"\n{stock.upper()}:")
    
    correlations = {}
    for signal in signal_cols:
        forward_corr = df[signal].corr(df[return_col].shift(-1))
        correlations[signal] = forward_corr
        correlation_results.append({
            'stock': stock,
            'signal': signal,
            'correlation': forward_corr
        })
    
    sorted_corrs = sorted(correlations.items(), key=lambda x: abs(x[1]), reverse=True)
    for sig, corr in sorted_corrs:
        print(f"  {sig}: {corr:+.4f}")

corr_df = pd.DataFrame(correlation_results)
corr_pivot = corr_df.pivot(index='signal', columns='stock', values='correlation')

plt.figure(figsize=(10, 8))
sns.heatmap(corr_pivot, annot=True, fmt='.3f', cmap='RdYlGn', center=0, vmin=-0.4, vmax=0.4)
plt.title('Signal-Return Correlations', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('correlation_heatmap.png', dpi=150, bbox_inches='tight')
print("\n✓ Saved correlation_heatmap.png")

fig, axes = plt.subplots(2, 3, figsize=(15, 8))
axes = axes.flatten()

for idx, signal in enumerate(signal_cols):
    if idx < len(axes):
        axes[idx].hist(df[signal].dropna(), bins=50, edgecolor='black', alpha=0.7)
        axes[idx].set_title(f'{signal}')
        axes[idx].axvline(0, color='red', linestyle='--')

plt.tight_layout()
plt.savefig('signal_distributions.png', dpi=150, bbox_inches='tight')
print("✓ Saved signal_distributions.png")

fig, axes = plt.subplots(3, 1, figsize=(15, 10))
for idx, stock in enumerate(stock_cols):
    axes[idx].plot(df[stock].values)
    axes[idx].set_title(f'{stock} Price Over Time')
    axes[idx].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('stock_timeseries.png', dpi=150, bbox_inches='tight')
print("✓ Saved stock_timeseries.png")

print("\n✓ EDA COMPLETE")
