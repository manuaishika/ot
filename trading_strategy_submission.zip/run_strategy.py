import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import argparse
import os
from strategy import SignalMatchedStrategy

def create_performance_plots(returns_df, metrics, output_dir='.'):
    """Generate comprehensive performance plots"""
    
    portfolio_returns = returns_df['portfolio_return'].dropna()
    cumulative_pnl = (1 + portfolio_returns).cumprod()
    
    fig = plt.figure(figsize=(16, 12))
    
    ax1 = plt.subplot(3, 2, 1)
    ax1.plot(cumulative_pnl.values, linewidth=2, color='darkblue')
    ax1.set_title('Cumulative PnL', fontsize=12, fontweight='bold')
    ax1.set_xlabel('Time Period')
    ax1.set_ylabel('Cumulative Return')
    ax1.grid(True, alpha=0.3)
    ax1.axhline(y=1, color='red', linestyle='--', alpha=0.5, label='Breakeven')
    ax1.legend()
    
    ax2 = plt.subplot(3, 2, 2)
    rolling_sharpe = portfolio_returns.rolling(252).apply(
        lambda x: x.mean() / x.std() * np.sqrt(252) if len(x) > 1 and x.std() > 0 else 0
    )
    ax2.plot(rolling_sharpe.values, linewidth=2, color='orange')
    ax2.set_title('Rolling 252-Period Sharpe Ratio', fontsize=12, fontweight='bold')
    ax2.set_xlabel('Time Period')
    ax2.set_ylabel('Sharpe Ratio')
    ax2.grid(True, alpha=0.3)
    ax2.axhline(y=0, color='red', linestyle='--', alpha=0.5)
    
    ax3 = plt.subplot(3, 2, 3)
    ax3.hist(portfolio_returns, bins=50, edgecolor='black', alpha=0.7)
    ax3.set_title('Return Distribution', fontsize=12, fontweight='bold')
    ax3.set_xlabel('Return')
    ax3.set_ylabel('Frequency')
    ax3.axvline(x=0, color='red', linestyle='--', linewidth=2)
    ax3.axvline(x=portfolio_returns.mean(), color='green', linestyle='--', 
                linewidth=2, label=f'Mean: {portfolio_returns.mean():.6f}')
    ax3.legend()
    
    ax4 = plt.subplot(3, 2, 4)
    running_max = cumulative_pnl.expanding().max()
    drawdown = (cumulative_pnl - running_max) / running_max
    ax4.fill_between(range(len(drawdown)), drawdown.values, 0, 
                      alpha=0.3, color='red')
    ax4.plot(drawdown.values, linewidth=2, color='darkred')
    ax4.set_title('Drawdown Over Time', fontsize=12, fontweight='bold')
    ax4.set_xlabel('Time Period')
    ax4.set_ylabel('Drawdown')
    ax4.grid(True, alpha=0.3)
    
    ax5 = plt.subplot(3, 2, 5)
    ax5.plot(portfolio_returns.values, linewidth=1, alpha=0.7, color='navy')
    ax5.set_title('Period Returns', fontsize=12, fontweight='bold')
    ax5.set_xlabel('Time Period')
    ax5.set_ylabel('Return')
    ax5.grid(True, alpha=0.3)
    ax5.axhline(y=0, color='red', linestyle='--', alpha=0.5)
    
    ax6 = plt.subplot(3, 2, 6)
    ax6.axis('off')
    
    metrics_text = f"""
    PERFORMANCE METRICS
    {'='*35}
    
    Total Return:      {metrics['total_return']:.4f}
    Mean Return:       {metrics['mean_return']:.6f}
    Std Return:        {metrics['std_return']:.6f}
    
    Sharpe Ratio:      {metrics['sharpe_ratio']:.3f}
    Max Drawdown:      {metrics['max_drawdown']:.3f}
    Win Rate:          {metrics['win_rate']:.3f}
    
    Number of Trades:  {metrics['num_trades']:.0f}
    Final PnL:         {metrics['final_pnl']:.4f}
    """
    
    ax6.text(0.1, 0.5, metrics_text, fontsize=11, family='monospace',
             verticalalignment='center')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'strategy_performance.png'), 
                dpi=150, bbox_inches='tight')
    print(f"✓ Saved strategy_performance.png")
    plt.close()

def main():
    parser = argparse.ArgumentParser(description='Run trading strategy on test data')
    parser.add_argument('--input', type=str, default='test.csv', 
                       help='Input CSV file')
    parser.add_argument('--output', type=str, default='predictions.csv', 
                       help='Output predictions CSV')
    parser.add_argument('--metrics', type=str, default='metrics.csv', 
                       help='Output metrics CSV')
    parser.add_argument('--pnl', type=str, default='pnl.csv', 
                       help='Output cumulative PnL CSV')
    parser.add_argument('--plots', action='store_true', 
                       help='Generate performance plots')
    args = parser.parse_args()
    
    print("="*70)
    print("TRADING STRATEGY - TEST SET EVALUATION")
    print("="*70)
    
    print(f"\nLoading data from {args.input}...")
    df = pd.read_csv(args.input)
    print(f"✓ Loaded {len(df)} rows")
    print(f"✓ Columns: {df.columns.tolist()}")
    
    print("\nInitializing strategy...")
    strategy = SignalMatchedStrategy()
    print(f"✓ Signal mapping: {strategy.signal_map}")
    print(f"✓ Position scale: {strategy.position_scale}")
    
    print("\nRunning backtest...")
    positions, returns, metrics = strategy.backtest(df)
    
    portfolio_returns = returns['portfolio_return'].dropna()
    cumulative_pnl = (1 + portfolio_returns).cumprod()
    
    print("\n" + "="*70)
    print("PERFORMANCE METRICS")
    print("="*70)
    for key, value in metrics.items():
        if isinstance(value, float):
            print(f"{key:20s}: {value:.6f}")
        else:
            print(f"{key:20s}: {value}")
    
    print(f"\nSaving predictions to {args.output}...")
    portfolio_returns.to_csv(args.output, index=False, header=False)
    print(f"✓ Saved {len(portfolio_returns)} predictions")
    
    print(f"\nSaving cumulative PnL to {args.pnl}...")
    cumulative_pnl.to_csv(args.pnl, index=False, header=['cumulative_pnl'])
    print(f"✓ Saved {len(cumulative_pnl)} PnL values")
    
    print(f"\nSaving metrics to {args.metrics}...")
    metrics_df = pd.DataFrame([metrics])
    metrics_df.to_csv(args.metrics, index=False)
    print(f"✓ Saved metrics")
    
    print("\nGenerating performance plots...")
    create_performance_plots(returns, metrics)
    
    print("\n" + "="*70)
    print("✓ EXECUTION COMPLETE")
    print("="*70)
    print(f"Generated files:")
    print(f"  - {args.output} (predictions)")
    print(f"  - {args.pnl} (cumulative PnL)")
    print(f"  - {args.metrics} (performance metrics)")
    print(f"  - strategy_performance.png (visualizations)")
    print("="*70)

if __name__ == "__main__":
    main()
